`--slots` *positive integer*
: This option is ignored. It is provided for compatibility with
  usearch.
