/*

  VSEARCH: a versatile open source tool for metagenomics

  Copyright (C) 2014-2026, Torbjorn Rognes, Frederic Mahe and Tomas Flouri
  All rights reserved.

  Contact: Torbjorn Rognes <torognes@ifi.uio.no>,
  Department of Informatics, University of Oslo,
  PO Box 1080 Blindern, NO-0316 Oslo, Norway

  This software is dual-licensed and available under a choice
  of one of two licenses, either under the terms of the GNU
  General Public License version 3 or the BSD 2-Clause License.


  GNU General Public License version 3

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.


  The BSD 2-Clause License

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.

*/

#include "vsearch.h"
#include "search.h"
#include "searchcore.h"
#include "align_simd.h"
#include "dbindex.h"
#include "mask.h"
#include "minheap.h"
#include "otutable.h"
#include "udb.h"
#include "unique.h"
#include "utils/fatal.hpp"
#include "utils/maps.hpp"
#include "utils/xpthread.hpp"
#include <algorithm>  // std::min
#include <cinttypes>  // macros PRIu64 and PRId64
#include <cstdint> // uint64_t, int64_t
#include <cstdio>  // std::FILE, std::fprintf, std::fclose, std::size_t
#include <cstring>  // std::strlen, std::memset, std::strcpy
#include <pthread.h>
#include <vector>


static struct searchinfo_s * si_plus;
static struct searchinfo_s * si_minus;
static pthread_t * pthread;

/* global constants/data, no need for synchronization */
static int tophits; /* the maximum number of hits to keep */
static int seqcount; /* number of database sequences */
static pthread_attr_t attr;
static fastx_handle query_fastx_h;

/* global data protected by mutex */
static pthread_mutex_t mutex_input;
static pthread_mutex_t mutex_output;
static int qmatches;
static uint64_t qmatches_abundance;
static int queries;
static uint64_t queries_abundance;
static uint64_t * dbmatched;
static FILE * fp_samout = nullptr;
static FILE * fp_alnout = nullptr;
static FILE * fp_userout = nullptr;
static FILE * fp_blast6out = nullptr;
static FILE * fp_uc = nullptr;
static FILE * fp_fastapairs = nullptr;
static FILE * fp_matched = nullptr;
static FILE * fp_notmatched = nullptr;
static FILE * fp_dbmatched = nullptr;
static FILE * fp_dbnotmatched = nullptr;
static FILE * fp_otutabout = nullptr;
static FILE * fp_mothur_shared_out = nullptr;
static FILE * fp_biomout = nullptr;
static FILE * fp_lcaout = nullptr;
static FILE * fp_qsegout = nullptr;
static FILE * fp_tsegout = nullptr;

static int count_matched = 0;
static int count_notmatched = 0;

auto search_output_results(std::vector<struct hit> const & hits,
                           char const * query_head,
                           int qseqlen,
                           char const * qsequence,
                           char const * qsequence_rc,
                           int qsize) -> void
{
  xpthread_mutex_lock(&mutex_output);

  /* show results */
  auto const toreport = std::min(opt_maxhits, static_cast<int64_t>(hits.size()));

  if (fp_alnout != nullptr)
    {
      results_show_alnout(fp_alnout,
                          hits.data(),
                          toreport,
                          query_head,
                          qsequence,
                          qseqlen);
    }

  if (fp_lcaout != nullptr)
    {
      results_show_lcaout(fp_lcaout,
                          hits.data(),
                          toreport,
                          query_head);
    }

  if (fp_samout != nullptr)
    {
      results_show_samout(fp_samout,
                          hits.data(),
                          toreport,
                          query_head,
                          qsequence,
                          qsequence_rc);
    }

  if (toreport != 0)  // hits.size() >=1 and <= opt_maxhits
    {
      double const top_hit_id = hits[0].id;

      if ((opt_otutabout != nullptr) || (opt_mothur_shared_out != nullptr) || (opt_biomout != nullptr))
        {
          otutable_add(query_head,
                       db_getheader(hits[0].target),
                       qsize);
        }

      for (auto t = 0; t < toreport; t++)
        {
          auto const * hp = &hits[t];

          if ((opt_top_hits_only != 0) && (hp->id < top_hit_id))
            {
              break;
            }

          if (fp_fastapairs != nullptr)
            {
              results_show_fastapairs_one(fp_fastapairs,
                                          hp,
                                          query_head,
                                          qsequence,
                                          qsequence_rc);
            }

          if (fp_qsegout != nullptr)
            {
              results_show_qsegout_one(fp_qsegout,
                                       hp,
                                       query_head,
                                       qsequence,
                                       qseqlen,
                                       qsequence_rc);
            }

          if (fp_tsegout != nullptr)
            {
              results_show_tsegout_one(fp_tsegout,
                                       hp);
            }

          if (fp_uc != nullptr)
            {
              if ((t==0) || (opt_uc_allhits != 0))
                {
                  results_show_uc_one(fp_uc,
                                      hp,
                                      query_head,
                                      qseqlen,
                                      hp->target);
                }
            }

          if (fp_userout != nullptr)
            {
              results_show_userout_one(fp_userout,
                                       hp,
                                       query_head,
                                       qsequence,
                                       qseqlen,
                                       qsequence_rc);
            }

          if (fp_blast6out != nullptr)
            {
              results_show_blast6out_one(fp_blast6out,
                                         hp,
                                         query_head,
                                         qseqlen);
            }
        }
    }
  else
    {
      if ((opt_otutabout != nullptr) || (opt_mothur_shared_out != nullptr) || (opt_biomout != nullptr))
        {
          otutable_add(query_head,
                       nullptr,
                       qsize);
        }

      if (fp_uc != nullptr)
        {
          results_show_uc_one(fp_uc,
                              nullptr,
                              query_head,
                              qseqlen,
                              0);
        }

      if (opt_output_no_hits != 0)
        {
          if (fp_userout != nullptr)
            {
              results_show_userout_one(fp_userout,
                                       nullptr,
                                       query_head,
                                       qsequence,
                                       qseqlen,
                                       qsequence_rc);
            }

          if (fp_blast6out != nullptr)
            {
              results_show_blast6out_one(fp_blast6out,
                                         nullptr,
                                         query_head,
                                         qseqlen);
            }
        }
    }

  if (not hits.empty())
    {
      count_matched++;
      if (opt_matched != nullptr)
        {
          fasta_print_general(fp_matched,
                              nullptr,
                              qsequence,
                              qseqlen,
                              query_head,
                              strlen(query_head),
                              qsize,
                              count_matched,
                              -1.0,
                              -1, -1, nullptr, 0.0);
        }
    }
  else
    {
      count_notmatched++;
      if (opt_notmatched != nullptr)
        {
          fasta_print_general(fp_notmatched,
                              nullptr,
                              qsequence,
                              qseqlen,
                              query_head,
                              strlen(query_head),
                              qsize,
                              count_notmatched,
                              -1.0,
                              -1, -1, nullptr, 0.0);
        }
    }

  /* update matching db sequences */
  for (auto const & hit : hits) {
    if (hit.accepted or hit.weak) {
      dbmatched[hit.target] += opt_sizein ? qsize : 1;
    }
  }

  xpthread_mutex_unlock(&mutex_output);
}


auto search_query(int64_t t) -> int
{
  for (int s = 0; s < opt_strand; s++)
    {
      struct searchinfo_s * si = (s != 0) ? si_minus + t : si_plus + t;

      /* mask query */
      if (opt_qmask == MASK_DUST)
        {
          dust(si->qsequence, si->qseqlen);
        }
      else if ((opt_qmask == MASK_SOFT) && (opt_hardmask != 0))
        {
          hardmask(si->qsequence, si->qseqlen);
        }

      /* perform search */
      search_onequery(si, opt_qmask);
    }

  std::vector<struct hit> hits;

  search_joinhits(si_plus + t,
                  opt_strand > 1 ? si_minus + t : nullptr,
                  hits);

  search_output_results(hits,
                        si_plus[t].query_head,
                        si_plus[t].qseqlen,
                        si_plus[t].qsequence,
                        opt_strand > 1 ? si_minus[t].qsequence : nullptr,
                        si_plus[t].qsize);

  /* free memory for alignment strings */
  for (auto const & hit : hits) {
    if (hit.aligned) {
      xfree(hit.nwalignment);
    }
  }

  return static_cast<int>(hits.size());
}


static auto populate_si(struct searchinfo_s * si,
                        const char * head,
                        int head_len,
                        const char * seq,
                        int seq_len,
                        int query_no,
                        int qsize,
                        int strand) -> void
{
  si->query_head_len = head_len;
  si->qseqlen = seq_len;
  si->query_no = query_no;
  si->qsize = qsize;
  si->strand = strand;

  /* allocate more memory for header and sequence, if necessary */

  if (si->query_head_len + 1 > si->query_head_alloc)
    {
      si->query_head_alloc = si->query_head_len + 2001;
      si->query_head = (char *)
        xrealloc(si->query_head, (size_t) (si->query_head_alloc));
    }

  if (si->qseqlen + 1 > si->seq_alloc)
    {
      si->seq_alloc = si->qseqlen + 2001;
      si->qsequence = (char *)
        xrealloc(si->qsequence, (size_t) (si->seq_alloc));
    }

  /* copy header */
  strcpy(si->query_head, head);

  /* copy or reverse-complement sequence */
  if (strand == 0)
    {
      strcpy(si->qsequence, seq);
    }
  else
    {
      reverse_complement(si->qsequence, seq, seq_len);
    }
}


auto search_thread_run(int64_t t) -> void
{
  while (true)
    {
      xpthread_mutex_lock(&mutex_input);

      if (fastx_next(query_fastx_h,
                     (opt_notrunclabels == 0),
                     chrmap_no_change_vector.data()))
        {
          char const * qhead = fastx_get_header(query_fastx_h);
          int const query_head_len = fastx_get_header_length(query_fastx_h);
          char const * qseq = fastx_get_sequence(query_fastx_h);
          int const qseqlen = fastx_get_sequence_length(query_fastx_h);
          int const query_no = fastx_get_seqno(query_fastx_h);
          int const qsize = fastx_get_abundance(query_fastx_h);

          populate_si(si_plus + t,
                      qhead,
                      query_head_len,
                      qseq,
                      qseqlen,
                      query_no,
                      qsize,
                      0);

          /* get progress as amount of input file read */
          uint64_t const progress = fastx_get_position(query_fastx_h);

          /* let other threads read input */
          xpthread_mutex_unlock(&mutex_input);

          if (opt_strand > 1)
            {
              populate_si(si_minus + t,
                          si_plus[t].query_head,
                          query_head_len,
                          si_plus[t].qsequence,
                          qseqlen,
                          query_no,
                          qsize,
                          1);
            }

          int const match = search_query(t);

          /* lock mutex for update of global data and output */
          xpthread_mutex_lock(&mutex_output);

          /* update stats */
          ++queries;
          queries_abundance += qsize;

          if (match != 0)
            {
              ++qmatches;
              qmatches_abundance += qsize;
            }

          /* show progress */
          progress_update(progress);

          xpthread_mutex_unlock(&mutex_output);
        }
      else
        {
          xpthread_mutex_unlock(&mutex_input);
          break;
        }
    }
}


auto search_thread_init(struct searchinfo_s * si) -> void
{
  /* thread specific initialiation */
  si->uh = unique_init();
  si->kmers = (count_t *) xmalloc((seqcount * sizeof(count_t)) + 32);
  si->m = minheap_init(tophits);
  si->hits = (struct hit *) xmalloc
    (sizeof(struct hit) * tophits * opt_strand);
  si->qsize = 1;
  si->query_head_alloc = 0;
  si->query_head = nullptr;
  si->seq_alloc = 0;
  si->qsequence = nullptr;
  si->s = search16_init(opt_match,
                        opt_mismatch,
                        opt_gap_open_query_left,
                        opt_gap_open_target_left,
                        opt_gap_open_query_interior,
                        opt_gap_open_target_interior,
                        opt_gap_open_query_right,
                        opt_gap_open_target_right,
                        opt_gap_extension_query_left,
                        opt_gap_extension_target_left,
                        opt_gap_extension_query_interior,
                        opt_gap_extension_target_interior,
                        opt_gap_extension_query_right,
                        opt_gap_extension_target_right);
}


auto search_thread_exit(struct searchinfo_s * si) -> void
{
  /* thread specific clean up */
  search16_exit(si->s);
  unique_exit(si->uh);
  xfree(si->hits);
  minheap_exit(si->m);
  xfree(si->kmers);
  if (si->query_head != nullptr)
    {
      xfree(si->query_head);
    }
  if (si->qsequence != nullptr)
    {
      xfree(si->qsequence);
    }
}



auto search_thread_worker(void * vp) -> void *
{
  auto t = (int64_t) vp;
  search_thread_run(t);
  return nullptr;
}


auto search_thread_worker_run() -> void
{
  /* initialize threads, start them, join them and return */

  xpthread_attr_init(&attr);
  xpthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

  /* init and create worker threads, put them into stand-by mode */
  for (int t = 0; t < opt_threads; t++)
    {
      search_thread_init(si_plus + t);
      if (si_minus != nullptr)
        {
          search_thread_init(si_minus + t);
        }
      xpthread_create(pthread + t, &attr,
                      search_thread_worker, (void *) (int64_t) t);
    }

  /* finish and clean up worker threads */
  for (int t = 0; t < opt_threads; t++)
    {
      xpthread_join(pthread[t], nullptr);
      search_thread_exit(si_plus + t);
      if (si_minus != nullptr)
        {
          search_thread_exit(si_minus + t);
        }
    }

  xpthread_attr_destroy(&attr);
}


auto search_prep(char * cmdline, char * progheader) -> void
{
  /* open output files */

  if (opt_alnout != nullptr)
    {
      fp_alnout = fopen_output(opt_alnout);
      if (fp_alnout == nullptr)
        {
          fatal("Unable to open alignment output file for writing");
        }

      fprintf(fp_alnout, "%s\n", cmdline);
      fprintf(fp_alnout, "%s\n", progheader);
    }

  if (opt_lcaout != nullptr)
    {
      fp_lcaout = fopen_output(opt_lcaout);
      if (fp_lcaout == nullptr)
        {
          fatal("Unable to open lca output file for writing");
        }
    }

  if (opt_samout != nullptr)
    {
      fp_samout = fopen_output(opt_samout);
      if (fp_samout == nullptr)
        {
          fatal("Unable to open SAM output file for writing");
        }
    }

  if (opt_userout != nullptr)
    {
      fp_userout = fopen_output(opt_userout);
      if (fp_userout == nullptr)
        {
          fatal("Unable to open user-defined output file for writing");
        }
    }

  if (opt_blast6out != nullptr)
    {
      fp_blast6out = fopen_output(opt_blast6out);
      if (fp_blast6out == nullptr)
        {
          fatal("Unable to open blast6-like output file for writing");
        }
    }

  if (opt_uc != nullptr)
    {
      fp_uc = fopen_output(opt_uc);
      if (fp_uc == nullptr)
        {
          fatal("Unable to open uc output file for writing");
        }
    }

  if (opt_fastapairs != nullptr)
    {
      fp_fastapairs = fopen_output(opt_fastapairs);
      if (fp_fastapairs == nullptr)
        {
          fatal("Unable to open fastapairs output file for writing");
        }
    }

  if (opt_qsegout != nullptr)
    {
      fp_qsegout = fopen_output(opt_qsegout);
      if (fp_qsegout == nullptr)
        {
          fatal("Unable to open qsegout output file for writing");
        }
    }

  if (opt_tsegout != nullptr)
    {
      fp_tsegout = fopen_output(opt_tsegout);
      if (fp_tsegout == nullptr)
        {
          fatal("Unable to open tsegout output file for writing");
        }
    }

  if (opt_matched != nullptr)
    {
      fp_matched = fopen_output(opt_matched);
      if (fp_matched == nullptr)
        {
          fatal("Unable to open matched output file for writing");
        }
    }

  if (opt_notmatched != nullptr)
    {
      fp_notmatched = fopen_output(opt_notmatched);
      if (fp_notmatched == nullptr)
        {
          fatal("Unable to open notmatched output file for writing");
        }
    }

  if (opt_otutabout != nullptr)
    {
      fp_otutabout = fopen_output(opt_otutabout);
      if (fp_otutabout == nullptr)
        {
          fatal("Unable to open OTU table (text format) output file for writing");
        }
    }

  if (opt_mothur_shared_out != nullptr)
    {
      fp_mothur_shared_out = fopen_output(opt_mothur_shared_out);
      if (fp_mothur_shared_out == nullptr)
        {
          fatal("Unable to open OTU table (mothur format) output file for writing");
        }
    }

  if (opt_biomout != nullptr)
    {
      fp_biomout = fopen_output(opt_biomout);
      if (fp_biomout == nullptr)
        {
          fatal("Unable to open OTU table (biom 1.0 format) output file for writing");
        }
    }

  /* check if it may be an UDB file */

  bool const is_udb = udb_detect_isudb(opt_db);

  if (is_udb)
    {
      udb_read(opt_db, true, true);
      results_show_samheader(fp_samout, cmdline, opt_db);
      show_rusage();
      seqcount = db_getsequencecount();
    }
  else
    {
      db_read(opt_db, 0);
      results_show_samheader(fp_samout, cmdline, opt_db);
      if (opt_dbmask == MASK_DUST)
        {
          dust_all();
        }
      else if ((opt_dbmask == MASK_SOFT) && (opt_hardmask != 0))
        {
          hardmask_all();
        }
      show_rusage();
      seqcount = db_getsequencecount();
      dbindex_prepare(1, opt_dbmask);
      dbindex_addallsequences(opt_dbmask);
    }

  /* tophits = the maximum number of hits we need to store */

  if ((opt_maxrejects == 0) || (opt_maxrejects > seqcount))
    {
      opt_maxrejects = seqcount;
    }

  if ((opt_maxaccepts == 0) || (opt_maxaccepts > seqcount))
    {
      opt_maxaccepts = seqcount;
    }

  tophits = opt_maxrejects + opt_maxaccepts + MAXDELAYED;

  tophits = std::min(tophits, seqcount);
}


auto search_done() -> void
{
  /* clean up, global */

  dbindex_free();
  db_free();

  if (opt_lcaout != nullptr)
    {
      fclose(fp_lcaout);
    }
  if (opt_matched != nullptr)
    {
      fclose(fp_matched);
    }
  if (opt_notmatched != nullptr)
    {
      fclose(fp_notmatched);
    }
  if (opt_fastapairs != nullptr)
    {
      fclose(fp_fastapairs);
    }
  if (opt_qsegout != nullptr)
    {
      fclose(fp_qsegout);
    }
  if (opt_tsegout != nullptr)
    {
      fclose(fp_tsegout);
    }
  if (fp_uc != nullptr)
    {
      fclose(fp_uc);
    }
  if (fp_blast6out != nullptr)
    {
      fclose(fp_blast6out);
    }
  if (fp_userout != nullptr)
    {
      fclose(fp_userout);
      clean_up(); // free userfields allocation
    }
  if (fp_alnout != nullptr)
    {
      fclose(fp_alnout);
    }
  if (fp_samout != nullptr)
    {
      fclose(fp_samout);
    }
  show_rusage();
}


auto usearch_global(struct Parameters const & parameters, char * cmdline, char * progheader) -> void
{
  search_prep(cmdline, progheader);

  if (opt_dbmatched != nullptr)
    {
      fp_dbmatched = fopen_output(opt_dbmatched);
      if (fp_dbmatched == nullptr)
        {
          fatal("Unable to open dbmatched output file for writing");
        }
    }

  if (opt_dbnotmatched != nullptr)
    {
      fp_dbnotmatched = fopen_output(opt_dbnotmatched);
      if (fp_dbnotmatched == nullptr)
        {
          fatal("Unable to open dbnotmatched output file for writing");
        }
    }

  dbmatched = (uint64_t *) xmalloc(seqcount * sizeof(uint64_t *));
  std::memset(dbmatched, 0, seqcount * sizeof(uint64_t *));

  otutable_init();

  /* prepare reading of queries */
  qmatches = 0;
  qmatches_abundance = 0;
  queries = 0;
  queries_abundance = 0;
  query_fastx_h = fastx_open(parameters.opt_usearch_global);

  /* allocate memory for thread info */
  si_plus = (struct searchinfo_s *) xmalloc(opt_threads *
                                            sizeof(struct searchinfo_s));
  if (opt_strand > 1)
    {
      si_minus = (struct searchinfo_s *) xmalloc(opt_threads *
                                                 sizeof(struct searchinfo_s));
    }
  else
    {
      si_minus = nullptr;
    }

  pthread = (pthread_t *) xmalloc(opt_threads * sizeof(pthread_t));

  /* init mutexes for input and output */
  xpthread_mutex_init(&mutex_input, nullptr);
  xpthread_mutex_init(&mutex_output, nullptr);

  progress_init("Searching", fastx_get_size(query_fastx_h));
  search_thread_worker_run();
  progress_done();

  xpthread_mutex_destroy(&mutex_output);
  xpthread_mutex_destroy(&mutex_input);

  xfree(pthread);
  xfree(si_plus);
  if (si_minus != nullptr)
    {
      xfree(si_minus);
    }

  fastx_close(query_fastx_h);

  if (! opt_quiet)
    {
      fprintf(stderr, "Matching unique query sequences: %d of %d",
              qmatches, queries);
      if (queries > 0)
        {
          fprintf(stderr, " (%.2f%%)", 100.0 * qmatches / queries);
        }
      fprintf(stderr, "\n");
      if (opt_sizein)
        {
          fprintf(stderr, "Matching total query sequences: %" PRIu64 " of %"
                  PRIu64,
                  qmatches_abundance, queries_abundance);
          if (queries_abundance > 0)
            {
              fprintf(stderr, " (%.2f%%)",
                      100.0 * qmatches_abundance / queries_abundance);
            }
          fprintf(stderr, "\n");
        }
    }

  if (opt_log != nullptr)
    {
      fprintf(fp_log, "Matching unique query sequences: %d of %d",
              qmatches, queries);
      if (queries > 0)
        {
          fprintf(fp_log, " (%.2f%%)", 100.0 * qmatches / queries);
        }
      fprintf(fp_log, "\n");
      if (opt_sizein)
        {
          fprintf(fp_log, "Matching total query sequences: %" PRIu64 " of %"
                  PRIu64,
                  qmatches_abundance, queries_abundance);
          if (queries_abundance > 0)
            {
              fprintf(fp_log, " (%.2f%%)",
                      100.0 * qmatches_abundance / queries_abundance);
            }
          fprintf(fp_log, "\n");
        }
    }


  // Add OTUs with no matches to OTU table
  if ((opt_otutabout != nullptr) || (opt_mothur_shared_out != nullptr) || (opt_biomout != nullptr)) {
    for (int64_t i = 0; i < seqcount; i++) {
      if (dbmatched[i] == 0U) {
        otutable_add(nullptr, db_getheader(i), 0);
      }
    }
  }

  if (opt_biomout != nullptr)
    {
      otutable_print_biomout(fp_biomout);
      fclose(fp_biomout);
    }

  if (opt_otutabout != nullptr)
    {
      otutable_print_otutabout(fp_otutabout);
      fclose(fp_otutabout);
    }

  if (opt_mothur_shared_out != nullptr)
    {
      otutable_print_mothur_shared_out(fp_mothur_shared_out);
      fclose(fp_mothur_shared_out);
    }

  otutable_done();

  int count_dbmatched = 0;
  int count_dbnotmatched = 0;

  if ((opt_dbmatched != nullptr) || (opt_dbnotmatched != nullptr))
    {
      for (int64_t i = 0; i < seqcount; i++)
        {
          if (dbmatched[i] != 0U)
            {
              count_dbmatched++;
              if (opt_dbmatched != nullptr)
                {
                  fasta_print_general(fp_dbmatched,
                                      nullptr,
                                      db_getsequence(i),
                                      db_getsequencelen(i),
                                      db_getheader(i),
                                      db_getheaderlen(i),
                                      dbmatched[i],
                                      count_dbmatched,
                                      -1.0,
                                      -1, -1, nullptr, 0.0);
                }
            }
          else
            {
              count_dbnotmatched++;
              if (opt_dbnotmatched != nullptr)
                {
                  fasta_print_general(fp_dbnotmatched,
                                      nullptr,
                                      db_getsequence(i),
                                      db_getsequencelen(i),
                                      db_getheader(i),
                                      db_getheaderlen(i),
                                      db_getabundance(i),
                                      count_dbnotmatched,
                                      -1.0,
                                      -1, -1, nullptr, 0.0);
                }
            }
        }
    }

  xfree(dbmatched);

  if (opt_dbmatched != nullptr)
    {
      fclose(fp_dbmatched);
    }
  if (opt_dbnotmatched != nullptr)
    {
      fclose(fp_dbnotmatched);
    }

  search_done();
}


/* === Session-based search API (supports both-strand search) === */


struct search_session_s {
  struct searchinfo_s * si_plus = nullptr;
  struct searchinfo_s * si_minus = nullptr;  /* non-null when opt_strand > 1 */
};


auto search_session_alloc() -> struct search_session_s *
{
  return new search_session_s {};
}


auto search_session_free(struct search_session_s * ss) -> void
{
  if (ss != nullptr)
    {
      search_session_cleanup(ss);
      delete ss;
    }
}


auto search_session_init(struct search_session_s * ss) -> void
{
  /* Initialize search session for library use.
     Mirrors cluster_session_init: sets file-static seqcount/tophits,
     allocates si_plus (always) and si_minus (when opt_strand > 1). */
  seqcount = static_cast<int>(db_getsequencecount());
  tophits = opt_maxaccepts + opt_maxrejects + MAXDELAYED;
  if (tophits > seqcount)
    {
      tophits = seqcount;
    }

  ss->si_plus = new searchinfo_s {};
  search_thread_init(ss->si_plus);
  ss->si_plus->strand = 0;

  if (opt_strand > 1)
    {
      ss->si_minus = new searchinfo_s {};
      search_thread_init(ss->si_minus);
      ss->si_minus->strand = 1;
    }
}


auto search_session_single(struct search_session_s * ss,
                           const char * query_seq,
                           const char * query_head,
                           int query_len,
                           int query_size,
                           struct search_result_s * results,
                           int max_results,
                           int * result_count) -> void
{
  int const head_len = std::strlen(query_head);
  struct searchinfo_s * si = ss->si_plus;

  populate_si(ss->si_plus,
              query_head,
              head_len,
              query_seq,
              query_len,
              0,
              query_size,
              0);

  if (opt_strand > 1)
    {
      populate_si(ss->si_minus,
                  query_head,
                  head_len,
                  query_seq,
                  query_len,
                  0,
                  query_size,
                  1);
    }

  /* Mask and search each strand independently */
  for (int s = 0; s < opt_strand; s++)
    {
      struct searchinfo_s * strand_si =
        (s != 0) ? ss->si_minus : ss->si_plus;

      if (opt_qmask == MASK_DUST)
        {
          dust(strand_si->qsequence, strand_si->qseqlen);
        }
      else if ((opt_qmask == MASK_SOFT) && (opt_hardmask != 0))
        {
          hardmask(strand_si->qsequence, strand_si->qseqlen);
        }

      search_onequery(strand_si, opt_qmask);
    }

  /* Merge hits from both strands */
  std::vector<struct hit> hits;
  search_joinhits(ss->si_plus,
                  opt_strand > 1 ? ss->si_minus : nullptr,
                  hits);

  /* Populate results (search_joinhits returns only accepted/weak hits) */
  int count = 0;
  for (auto const & h : hits)
    {
      if (count >= max_results)
        {
          break;
        }
      auto & r = results[count];
      r.target = h.target;
      r.id = h.id;
      r.matches = h.matches;
      r.mismatches = h.mismatches;
      r.gaps = h.nwgaps;
      r.alignment_length = h.nwalignmentlength;
      r.query_length = si->qseqlen;
      r.target_length = (int) db_getsequencelen(h.target);
      r.accepted = h.accepted;
      r.strand = h.strand;
      ++count;
    }
  *result_count = count;

  /* Free alignment strings directly from si->hits (not the joinhits copy)
     to avoid dangling pointers. Follows cluster_assign_single pattern. */
  for (int s = 0; s < opt_strand; s++)
    {
      struct searchinfo_s * strand_si =
        (s != 0) ? ss->si_minus : ss->si_plus;
      for (int i = 0; i < strand_si->hit_count; ++i)
        {
          if (strand_si->hits[i].aligned &&
              strand_si->hits[i].nwalignment != nullptr)
            {
              xfree(strand_si->hits[i].nwalignment);
              strand_si->hits[i].nwalignment = nullptr;
            }
        }
    }
}


auto search_session_cleanup(struct search_session_s * ss) -> void
{
  if (ss->si_plus != nullptr)
    {
      search_thread_exit(ss->si_plus);
      delete ss->si_plus;
      ss->si_plus = nullptr;
    }
  if (ss->si_minus != nullptr)
    {
      search_thread_exit(ss->si_minus);
      delete ss->si_minus;
      ss->si_minus = nullptr;
    }
}


/* === Batch search API === */


/* Shared state for batch search worker threads */
struct search_batch_context_s {
  const char ** query_seqs;
  const char ** query_heads;
  const int * query_lens;
  const int * query_sizes;
  int query_count;
  struct search_result_s * results;
  int max_results_per_query;
  int * result_counts;

  /* per-thread search state arrays (sized to opt_threads) */
  struct searchinfo_s * batch_si_plus;
  struct searchinfo_s * batch_si_minus;  /* nullptr when opt_strand == 1 */

  /* work-stealing counter */
  pthread_mutex_t mutex;
  int next_query;
};


struct search_batch_worker_arg_s {
  struct search_batch_context_s * ctx;
  int thread_id;
};


static auto search_batch_worker_fn(void * vp) -> void *
{
  auto * arg = static_cast<struct search_batch_worker_arg_s *>(vp);
  auto * ctx = arg->ctx;
  int const tid = arg->thread_id;

  struct searchinfo_s * my_si_plus = ctx->batch_si_plus + tid;
  struct searchinfo_s * my_si_minus =
    (ctx->batch_si_minus != nullptr) ? ctx->batch_si_minus + tid : nullptr;

  while (true)
    {
      /* grab next query */
      xpthread_mutex_lock(&ctx->mutex);
      int const qi = ctx->next_query++;
      xpthread_mutex_unlock(&ctx->mutex);

      if (qi >= ctx->query_count)
        {
          break;
        }

      char const * qseq = ctx->query_seqs[qi];
      char const * qhead = ctx->query_heads[qi];
      int const qlen = ctx->query_lens[qi];
      int const qsize = ctx->query_sizes[qi];
      int const head_len = std::strlen(qhead);

      populate_si(my_si_plus,
                  qhead,
                  head_len,
                  qseq,
                  qlen,
                  qi,
                  qsize,
                  0);

      if (my_si_minus != nullptr)
        {
          populate_si(my_si_minus,
                      qhead,
                      head_len,
                      qseq,
                      qlen,
                      qi,
                      qsize,
                      1);
        }

      /* Mask and search each strand independently */
      for (int s = 0; s < opt_strand; s++)
        {
          struct searchinfo_s * strand_si =
            (s != 0) ? my_si_minus : my_si_plus;

          if (opt_qmask == MASK_DUST)
            {
              dust(strand_si->qsequence, strand_si->qseqlen);
            }
          else if ((opt_qmask == MASK_SOFT) && (opt_hardmask != 0))
            {
              hardmask(strand_si->qsequence, strand_si->qseqlen);
            }

          search_onequery(strand_si, opt_qmask);
        }

      /* Merge hits from both strands */
      std::vector<struct hit> hits;
      search_joinhits(my_si_plus,
                      opt_strand > 1 ? my_si_minus : nullptr,
                      hits);

      /* Populate results for this query */
      struct search_result_s * qresults =
        ctx->results + qi * ctx->max_results_per_query;
      int count = 0;
      for (auto const & h : hits)
        {
          if (count >= ctx->max_results_per_query)
            {
              break;
            }
          auto & r = qresults[count];
          r.target = h.target;
          r.id = h.id;
          r.matches = h.matches;
          r.mismatches = h.mismatches;
          r.gaps = h.nwgaps;
          r.alignment_length = h.nwalignmentlength;
          r.query_length = qlen;
          r.target_length = (int) db_getsequencelen(h.target);
          r.accepted = h.accepted;
          r.strand = h.strand;
          ++count;
        }
      ctx->result_counts[qi] = count;

      /* Free alignment strings from si->hits directly */
      for (int s = 0; s < opt_strand; s++)
        {
          struct searchinfo_s * strand_si =
            (s != 0) ? my_si_minus : my_si_plus;
          for (int i = 0; i < strand_si->hit_count; ++i)
            {
              if (strand_si->hits[i].aligned &&
                  strand_si->hits[i].nwalignment != nullptr)
                {
                  xfree(strand_si->hits[i].nwalignment);
                  strand_si->hits[i].nwalignment = nullptr;
                }
            }
        }
    }

  return nullptr;
}


auto search_batch(const char ** query_seqs,
                  const char ** query_heads,
                  const int * query_lens,
                  const int * query_sizes,
                  int query_count,
                  struct search_result_s * results,
                  int max_results_per_query,
                  int * result_counts) -> void
{
  /* Set up file-statics needed by search_thread_init */
  seqcount = static_cast<int>(db_getsequencecount());
  tophits = opt_maxaccepts + opt_maxrejects + MAXDELAYED;
  if (tophits > seqcount)
    {
      tophits = seqcount;
    }

  int const nthreads = static_cast<int>(opt_threads);

  /* Allocate per-thread search state */
  struct search_batch_context_s ctx;
  ctx.query_seqs = query_seqs;
  ctx.query_heads = query_heads;
  ctx.query_lens = query_lens;
  ctx.query_sizes = query_sizes;
  ctx.query_count = query_count;
  ctx.results = results;
  ctx.max_results_per_query = max_results_per_query;
  ctx.result_counts = result_counts;
  ctx.next_query = 0;

  ctx.batch_si_plus = (struct searchinfo_s *)
    xmalloc(nthreads * sizeof(struct searchinfo_s));
  if (opt_strand > 1)
    {
      ctx.batch_si_minus = (struct searchinfo_s *)
        xmalloc(nthreads * sizeof(struct searchinfo_s));
    }
  else
    {
      ctx.batch_si_minus = nullptr;
    }

  xpthread_mutex_init(&ctx.mutex, nullptr);

  /* Init per-thread state and launch threads */
  std::vector<pthread_t> threads(nthreads);
  std::vector<struct search_batch_worker_arg_s> args(nthreads);
  pthread_attr_t batch_attr;
  xpthread_attr_init(&batch_attr);
  xpthread_attr_setdetachstate(&batch_attr, PTHREAD_CREATE_JOINABLE);

  for (int t = 0; t < nthreads; t++)
    {
      std::memset((void*)(ctx.batch_si_plus + t), 0, sizeof(struct searchinfo_s));
      search_thread_init(ctx.batch_si_plus + t);
      if (ctx.batch_si_minus != nullptr)
        {
          std::memset((void*)(ctx.batch_si_minus + t), 0, sizeof(struct searchinfo_s));
          search_thread_init(ctx.batch_si_minus + t);
        }
      args[t].ctx = &ctx;
      args[t].thread_id = t;
      xpthread_create(&threads[t], &batch_attr,
                      search_batch_worker_fn, &args[t]);
    }

  /* Join and cleanup */
  for (int t = 0; t < nthreads; t++)
    {
      xpthread_join(threads[t], nullptr);
      search_thread_exit(ctx.batch_si_plus + t);
      if (ctx.batch_si_minus != nullptr)
        {
          search_thread_exit(ctx.batch_si_minus + t);
        }
    }

  xpthread_attr_destroy(&batch_attr);
  xpthread_mutex_destroy(&ctx.mutex);
  xfree(ctx.batch_si_plus);
  if (ctx.batch_si_minus != nullptr)
    {
      xfree(ctx.batch_si_minus);
    }
}
